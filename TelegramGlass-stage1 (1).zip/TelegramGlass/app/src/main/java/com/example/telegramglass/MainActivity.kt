package com.example.telegramglass

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val blue = Color(0xFF168AFF)
private val pages = listOf("Контакты", "Звонки", "Чаты", "Настройки")
private val icons = listOf(Icons.Default.People, Icons.Default.Call, Icons.AutoMirrored.Filled.Chat, Icons.Default.Settings)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        setContent { GlassApp() }
    }
}

@Composable
private fun GlassApp() {
    var selected by remember { mutableIntStateOf(2) }
    var dark by remember { mutableStateOf(false) }
    var detail by remember { mutableStateOf(false) }
    val bg = if (dark) Color(0xFF10131B) else Color(0xFFF4F7FD)
    val fg = if (dark) Color.White else Color(0xFF172338)
    val glass = if (dark) Color.White.copy(alpha = .13f) else Color.White.copy(alpha = .72f)
    MaterialTheme(colorScheme = if (dark) darkColorScheme(primary = blue) else lightColorScheme(primary = blue)) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(bg, if (dark) Color(0xFF202C45) else Color(0xFFDCEAFF), bg)))) {
            Column(Modifier.fillMaxSize()) {
                Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (detail) IconButton(onClick = { detail = false }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Назад", tint = blue) }
                    Text(if (detail) "Переписка" else pages[selected], fontSize = 30.sp, fontWeight = FontWeight.Bold, color = fg, modifier = Modifier.weight(1f))
                    if (!detail && selected == 3) Switch(checked = dark, onCheckedChange = { dark = it })
                    else if (!detail) Icon(Icons.Default.Search, "Поиск", tint = blue)
                }
                when {
                    detail -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text("Сообщения появятся после подключения TDLib.\nОтправка пока недоступна.", color = fg)
                    }
                    selected == 2 -> {
                        OutlinedTextField(value = "", onValueChange = {}, enabled = false, placeholder = { Text("Поиск сообщений и людей") }, leadingIcon = { Icon(Icons.Default.Search, null) }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(20.dp)))
                        Spacer(Modifier.height(12.dp))
                        Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(22.dp)).background(glass).clickable { detail = true }.padding(22.dp)) {
                            Column { Text("Подключение Telegram", color = fg, fontWeight = FontWeight.SemiBold); Spacer(Modifier.height(6.dp)); Text("Список чатов появится после авторизации через TDLib", color = fg.copy(alpha = .65f), fontSize = 13.sp) }
                        }
                    }
                    selected == 3 -> Column(Modifier.padding(20.dp)) {
                        GlassRow("Оформление", "Liquid Glass · прототип", glass, fg)
                        Spacer(Modifier.height(10.dp))
                        GlassRow("Аккаунт", "Авторизация ещё не подключена", glass, fg)
                        Spacer(Modifier.height(10.dp))
                        GlassRow("Безопасность", "Локальная сессия TDLib — следующий этап", glass, fg)
                    }
                    else -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text("${pages[selected]}: данные будут доступны после интеграции TDLib", color = fg)
                    }
                }
            }
            if (!detail) Row(Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp).fillMaxWidth().clip(RoundedCornerShape(32.dp)).background(glass).border(1.dp, Color.White.copy(alpha = .5f), RoundedCornerShape(32.dp)).padding(7.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                pages.forEachIndexed { index, page ->
                    val active = selected == index
                    Column(Modifier.weight(1f).clip(RoundedCornerShape(24.dp)).background(if (active) blue.copy(alpha = .16f) else Color.Transparent).clickable { selected = index }.padding(vertical = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(icons[index], page, tint = if (active) blue else fg.copy(alpha = .65f))
                        Text(page, fontSize = 10.sp, color = if (active) blue else fg.copy(alpha = .7f))
                    }
                }
            }
        }
    }
}

@Composable
private fun GlassRow(title: String, subtitle: String, glass: Color, fg: Color) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(glass).padding(18.dp)) {
        Text(title, color = fg, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(5.dp))
        Text(subtitle, color = fg.copy(alpha = .65f), fontSize = 13.sp)
    }
}
